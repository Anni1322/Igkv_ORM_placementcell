import { Component } from '@angular/core';

@Component({
  selector: 'app-c-jobpost',
  templateUrl: './c-jobpost.component.html',
  styleUrls: ['./c-jobpost.component.scss']
})
export class CJobpostComponent {

}
