import { Component } from '@angular/core';

@Component({
  selector: 'app-s-job-serch',
  templateUrl: './s-job-serch.component.html',
  styleUrls: ['./s-job-serch.component.scss']
})
export class SJobSerchComponent {

}
