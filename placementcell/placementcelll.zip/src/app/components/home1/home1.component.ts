import { Component, OnDestroy, OnInit, Renderer2 } from '@angular/core';
 

@Component({
  selector: 'app-home1',
  templateUrl: './home1.component.html',
  styleUrls: ['./home1.component.scss']
})
export class Home1Component  implements OnInit {
  focus:any;
  focus1:any;
  focus2:any;
  constructor() { }

  ngOnInit() {
  }
}