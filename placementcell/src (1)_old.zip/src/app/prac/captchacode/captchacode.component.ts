import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CServiceService } from 'src/app/components/company/service/c-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-captchacode',
  templateUrl: './captchacode.component.html',
  styleUrls: ['./captchacode.component.scss']
})
export class CaptchacodeComponent  {
  

}
