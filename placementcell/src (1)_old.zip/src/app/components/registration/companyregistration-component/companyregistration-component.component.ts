import { Component } from '@angular/core';

@Component({
  selector: 'app-companyregistration-component',
  templateUrl: './companyregistration-component.component.html',
  styleUrls: ['./companyregistration-component.component.scss']
})
export class CompanyregistrationComponentComponent {

}
