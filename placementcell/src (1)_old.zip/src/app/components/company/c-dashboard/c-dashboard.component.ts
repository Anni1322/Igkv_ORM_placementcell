import { Component } from '@angular/core';

@Component({
  selector: 'app-c-dashboard',
  templateUrl: './c-dashboard.component.html',
  styleUrls: ['./c-dashboard.component.scss']
})
export class CDashboardComponent {

}
