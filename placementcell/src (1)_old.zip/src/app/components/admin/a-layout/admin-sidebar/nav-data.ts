export const navbarData =[

    {
        routerLink: 'admin-dashboard',
        icon:'fal fa-home',
        label:'admin-dashboard'
    },

    {
        routerLink: 'Statistics',
        icon:'fal fa-chart-bar',
        label:'Statistics'
    },
    {
        routerLink: 'student',
        icon:'fal fa-tags',
        label:'student'
    }


];