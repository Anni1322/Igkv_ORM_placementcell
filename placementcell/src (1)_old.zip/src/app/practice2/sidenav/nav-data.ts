export const navbarData =[

    {
        routerLink: '',
        icon:'fal fa-home',
        label:'Dashboard'
    },
    {
        routerLink: 'student',
        icon:'fal fa-user-graduate',
        label:'student'
    },
    // {
    //     routerLink: 'student_registraion',
    //     icon:'fal fa-user-plus',
    //     label:'student_registraion'
    // },

    // {
    //     routerLink: 'company_registraion',
    //     icon:'fal fa-handshake',
    //     label:'company_registraion'
    // },
    {
        routerLink: 'admin',
        icon:'fal fa-user',
        label:'admin'
    },
    {
        routerLink: 'company',
        icon:'fal fa-business-time',
        label:'company'
    }


];