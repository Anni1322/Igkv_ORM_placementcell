import { Component } from '@angular/core';

@Component({
  selector: 'app-company-slider',
  templateUrl: './company-slider.component.html',
  styleUrls: ['./company-slider.component.scss']
})
export class CompanySliderComponent {

}
