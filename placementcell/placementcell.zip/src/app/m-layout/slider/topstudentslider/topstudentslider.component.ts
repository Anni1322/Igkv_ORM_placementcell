import { Component } from '@angular/core';

@Component({
  selector: 'app-topstudentslider',
  templateUrl: './topstudentslider.component.html',
  styleUrls: ['./topstudentslider.component.scss']
})
export class TopstudentsliderComponent {

}
