import { Component } from '@angular/core';

@Component({
  selector: 'app-top-student-slider',
  templateUrl: './top-student-slider.component.html',
  styleUrls: ['./top-student-slider.component.scss']
})
export class TopStudentSliderComponent {

}
