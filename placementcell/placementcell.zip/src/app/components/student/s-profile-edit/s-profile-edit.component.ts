import { Component } from '@angular/core';

@Component({
  selector: 'app-s-profile-edit',
  templateUrl: './s-profile-edit.component.html',
  styleUrls: ['./s-profile-edit.component.scss']
})
export class SProfileEditComponent {

}
