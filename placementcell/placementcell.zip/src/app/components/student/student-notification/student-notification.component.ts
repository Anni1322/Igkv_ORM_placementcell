import { Component } from '@angular/core';

@Component({
  selector: 'app-student-notification',
  templateUrl: './student-notification.component.html',
  styleUrls: ['./student-notification.component.scss']
})
export class StudentNotificationComponent {

}
