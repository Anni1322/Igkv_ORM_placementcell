export const environment = {
    production: false,
    baseImageUrl: 'http://localhost:3000/company',
    apiUrl :'http://localhost:3000',
    
    studentDetail_Get_Url: 'http://localhost:3000/student/student_List',
    studentDetail_Post_Url:  'http://localhost:3000/student/registration',
  };
  